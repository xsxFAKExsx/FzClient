package net.aspw.client.utils

object TransferUtils : MinecraftInstance() {
    var noMotionSet = false
}