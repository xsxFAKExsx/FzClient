package net.aspw.client.utils;

import net.minecraft.client.Minecraft;

public class MinecraftInstance {
    protected static final Minecraft mc = Minecraft.getMinecraft();
}
