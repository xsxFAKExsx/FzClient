package net.aspw.client.features.module.impl.visual

import net.aspw.client.features.module.Module
import net.aspw.client.features.module.ModuleCategory
import net.aspw.client.features.module.ModuleInfo

@ModuleInfo(name = "ViewClip", spacedName = "View Clip", category = ModuleCategory.VISUAL, array = false)
class ViewClip : Module()