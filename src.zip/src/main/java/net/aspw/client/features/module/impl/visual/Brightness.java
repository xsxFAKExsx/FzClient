package net.aspw.client.features.module.impl.visual;

import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;

@ModuleInfo(name = "Brightness", category = ModuleCategory.VISUAL, array = false)
public class Brightness extends Module {
}