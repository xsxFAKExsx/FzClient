package net.aspw.client.features.module.impl.other

import net.aspw.client.features.module.Module
import net.aspw.client.features.module.ModuleCategory
import net.aspw.client.features.module.ModuleInfo

@ModuleInfo(name = "LiquidInteract", spacedName = "Liquid Interact", category = ModuleCategory.OTHER)
class LiquidInteract : Module()