package net.aspw.client.features.module.impl.visual

import net.aspw.client.features.module.Module
import net.aspw.client.features.module.ModuleCategory
import net.aspw.client.features.module.ModuleInfo

@ModuleInfo(name = "NoHurt", spacedName = "No Hurt", category = ModuleCategory.VISUAL, array = false)
class NoHurt : Module()
