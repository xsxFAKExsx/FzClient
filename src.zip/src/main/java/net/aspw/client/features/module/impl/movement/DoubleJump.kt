package net.aspw.client.features.module.impl.movement

import net.aspw.client.features.module.Module
import net.aspw.client.features.module.ModuleCategory
import net.aspw.client.features.module.ModuleInfo

@ModuleInfo(name = "DoubleJump", spacedName = "Double Jump", category = ModuleCategory.MOVEMENT)
class DoubleJump : Module()