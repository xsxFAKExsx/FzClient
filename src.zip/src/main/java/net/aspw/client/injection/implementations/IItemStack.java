package net.aspw.client.injection.implementations;

public interface IItemStack {
    long getItemDelay();
}