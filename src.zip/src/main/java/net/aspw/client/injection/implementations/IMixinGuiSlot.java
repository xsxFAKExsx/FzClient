package net.aspw.client.injection.implementations;

public interface IMixinGuiSlot {

    void setListWidth(int listWidth);

    void setEnableScissor(boolean b);

}